<?php
    require "vendor/autoload.php";

    use Web3\Web3;

    $wallet_address = $_GET["wallet_address"];
    $block_number = $_GET["block_number"];

    $web3 = new Web3('http://localhost:8545');
    $eth = $web3->eth;

   $eth->blockNumber(function($error, $result) use ($block_number, $eth) 
   {
        if ($error !== null) 
        {
            printf("Error occurred: %s",$error->getMessage());
        }
        else
        {
            for ($i = $block_number; $i <= $result; $i++) 
            {
                $eth->getBlockByNumber($i, function($error, $block) 
                {
                    if ($error !== null) 
                    {
                        printf("Error occurred: %s",$error->getMessage());
                    }
                    else
                    {
                        foreach ($block['transactions'] as $transaction) 
                        {
                            $from_address = $transaction['from'];
                            $to_address = $transaction['to'];
                            $amount = $transaction['value'];

                            printf("From: %s<br>", $from_address);
                            printf("To: %s<br>", $to_address);
                            printf("Amount: %d ETH", $amount);
                        }
                    }   
                });
            }
        }
    });
?>

